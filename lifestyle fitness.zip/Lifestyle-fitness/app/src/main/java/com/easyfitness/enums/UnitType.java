package com.easyfitness.enums;

public enum UnitType {
    WEIGHT,
    DISTANCE,
    SIZE,
    PERCENTAGE,
    WEIGHT_OR_PERCENTAGE,
    NONE
}
